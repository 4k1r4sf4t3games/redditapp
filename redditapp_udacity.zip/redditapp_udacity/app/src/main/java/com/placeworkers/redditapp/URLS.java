package com.placeworkers.redditapp;

/**
 * Created by 4k1r4sf4t3 on 5/30/2018.
 */

public class URLS {

    public static final String BASE_URL = "https://www.reddit.com/r/";
    public static final String LOGIN_URL = "https://www.reddit.com/api/login/";
    public static final String COMMENT_URL = "https://www.reddit.com/api/";
}
